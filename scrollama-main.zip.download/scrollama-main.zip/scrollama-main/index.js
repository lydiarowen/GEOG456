import entry from "./src/entry";

export default entry;
