export default function err(msg) {
	console.error(`scrollama error: ${msg}`);
}