export default function getIndex(node) {
	return +node.getAttribute("data-scrollama-index");
}
